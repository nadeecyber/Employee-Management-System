<header>
    <div class="logo">
        <img src="../asset/logo.jpg" alt="Employee Management System Logo">
    </div>
    <div class="header-text">
        Employee Management System - Bit Lord
    </div>
</header>