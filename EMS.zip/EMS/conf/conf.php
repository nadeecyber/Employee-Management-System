<?php


$conn = new mysqli('localhost', 'root', '', 'emsdb');


?>